from django.apps import AppConfig


class AbcConfig(AppConfig):
    name = 'ABC'
