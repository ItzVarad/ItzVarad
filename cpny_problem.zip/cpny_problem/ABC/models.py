from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
class User(AbstractUser):
    pass  

class Company(models.Model):     
    user = models.ForeignKey("User", on_delete=models.CASCADE)     
    c_name = models.ForeignKey("Company", on_delete=models.CASCADE)      
    owner_name = models.CharField(max_length=255) 
    Type = models.CharField(max_length=255)         
    
    
    def __str__(self):         
        return f"{self.c_name}"
    
class Problem(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE) 
    c_name = models.ForeignKey("Company", on_delete=models.CASCADE) 
    problem = models.CharField(max_length=255)
    From_date = models.DateTimeField()
    to_date = models.DateTimeField()
    Image_urls = models.CharField(max_length=255)
    Video_urls = models.CharField(max_length=255)


class Students(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE)  
    s_name = models.CharField(max_length=255)
    mobile = models.CharField(max_length=255)
    branch = models.CharField(max_length=255)
    education = models.CharField(max_length=255)
    state = models.CharField(max_length=255)
    district = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    
    
    
class Solution(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE)
    s_name = models.CharField(max_length=255)
    problem = models.CharField(max_length=255)
    From_date = models.DateTimeField()
    to_date = models.DateTimeField()
    

class Solution_Progress(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE)
    curr_date = models.DateTimeField()
    Solu_name = models.CharField(max_length=255)
    progess = models.CharField(max_length=255)
    progress_details = models.CharField(max_length=255)
    Image_urls = models.CharField(max_length=255)
    Video_urls = models.CharField(max_length=255)
